package com.student.studentmanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentmanagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
